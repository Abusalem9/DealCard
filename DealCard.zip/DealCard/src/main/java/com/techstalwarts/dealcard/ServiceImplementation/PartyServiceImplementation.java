package com.techstalwarts.dealcard.ServiceImplementation;

import com.techstalwarts.dealcard.Entity.Party;
import com.techstalwarts.dealcard.Repository.PartyRepository;
import com.techstalwarts.dealcard.Service.PartyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PartyServiceImplementation implements PartyService {
    @Autowired
    PartyRepository partyRepository;

    @Override
    public Party createParty(Party party) {
        return partyRepository.save(party);
    }
}

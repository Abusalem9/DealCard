package com.techstalwarts.dealcard.Service;

import com.techstalwarts.dealcard.Entity.Party;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

public interface PartyService {
    Party createParty(Party party);
}

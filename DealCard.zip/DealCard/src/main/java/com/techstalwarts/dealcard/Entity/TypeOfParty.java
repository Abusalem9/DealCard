package com.techstalwarts.dealcard.Entity;

public enum TypeOfParty {
    BORROWER,LEDGER,BANK;
}

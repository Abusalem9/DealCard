package com.techstalwarts.dealcard.Entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Setter
@Getter
public class Party {
    @Id
    private Integer Id;
    private Integer dealId;
    private String partyFullName;
    private String email;
    private String mobile;
    private String partySignatoryName;
    private TypeOfParty typeOfParty;
    private PartyConsultantType partyConsultantType;
    private String partyBranch;
}

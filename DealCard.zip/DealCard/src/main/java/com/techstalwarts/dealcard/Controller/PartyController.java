package com.techstalwarts.dealcard.Controller;

import com.techstalwarts.dealcard.Entity.Party;
import com.techstalwarts.dealcard.Service.PartyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class PartyController {
    @Autowired
    PartyService partyService;

    @PostMapping("/party/create")
    public Party createParty(@RequestBody Party party){
        return partyService.createParty(party);
    }
}

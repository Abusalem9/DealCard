package com.techstalwarts.dealcard.ServiceImplementation;

import com.techstalwarts.dealcard.Entity.Deal;
import com.techstalwarts.dealcard.Repository.DealRepository;
import com.techstalwarts.dealcard.Service.DealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DealServiceImplementation implements DealService {
    @Autowired
    DealRepository dealRepository;

    @Override
    public Deal createDeal(Deal deal) {
        return dealRepository.save(deal);
    }

    @Override
    public Deal updateDeal(Deal deal) {
        Deal d = dealRepository.getById(deal.getDealId());
        if(d!=null){
            return dealRepository.save(d);
        }
        else
            throw new RuntimeException("Deal is not present");
    }

    @Override
    public String deleteDealByDealId(Integer dealId) {
        dealRepository.delete(dealRepository.getReferenceById(dealId));
        return "Deleted Successfully";
    }

    @Override
    public List<Deal> getAllDeals() {
        return dealRepository.findAll();
    }

    @Override
    public Deal getDeal(Integer id) {
        return dealRepository.getReferenceById(id);
    }
}

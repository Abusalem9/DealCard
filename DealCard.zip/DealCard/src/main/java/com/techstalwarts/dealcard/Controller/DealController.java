package com.techstalwarts.dealcard.Controller;

import com.techstalwarts.dealcard.Entity.Deal;
import com.techstalwarts.dealcard.Service.DealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class DealController {
    @Autowired
    private DealService dealService;

    @PostMapping("/deals/create")
    public Deal createDeal(@RequestBody Deal deal){
        return dealService.createDeal(deal);
    }

    @GetMapping("/deals/all")
    public List<Deal> getAllDeals(){
        return dealService.getAllDeals();
    }

    @GetMapping("deal/{id}")
    public Deal getDeal(@PathVariable("id") Integer id){
       return dealService.getDeal(id);
    }

}

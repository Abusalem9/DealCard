package com.techstalwarts.dealcard.Controller;

import com.techstalwarts.dealcard.helper.FileUploader;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Objects;

@RestController
@CrossOrigin(origins = "*")
public class fileUploadController {
    @Autowired
    private FileUploader fileUploader;
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file")MultipartFile file){

        if(file.isEmpty()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Content Not Found");
        }

        if(!Objects.equals(file.getContentType(), "application/pdf")){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please upload Pdf file Only");
        }

        boolean f =fileUploader.fileDone(file);
        if(f){
            return ResponseEntity.status(HttpStatus.OK).body("File is Successfully Uploaded.");
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File is Uploading Failed.");
    }
    @PostMapping("/ftp")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        String FTP_ADDRESS = "192.168.206.95";
        String LOGIN = "root";
        String PSW = "root";

        FTPClient con = null;

        try {
            con = new FTPClient();
            con.connect(FTP_ADDRESS);

            if (con.login(LOGIN, PSW)) {
                con.enterLocalPassiveMode(); // important!
                con.setFileType(FTP.BINARY_FILE_TYPE);

                boolean result = con.storeFile(file.getOriginalFilename(), file.getInputStream());
                con.logout();
                con.disconnect();
                redirectAttributes.addFlashAttribute("message","You successfully uploaded " + file.getOriginalFilename() + "!");
            }
            else {
                redirectAttributes.addFlashAttribute("Wrong","You successfully uploaded " + file.getOriginalFilename() + "!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message","Could not upload " + file.getOriginalFilename() + "!");
        }
        return "redirect:/";
    }
}

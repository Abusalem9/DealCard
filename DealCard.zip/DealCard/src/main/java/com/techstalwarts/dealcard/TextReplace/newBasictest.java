package com.techstalwarts.dealcard.TextReplace;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class newBasictest {
    public static void main(String[] args) {
        try {
            //Create a FTP Client
            FTPClient ftp = new FTPClient();

            //Set Host Information
            ftp.connect("192.168.206.95");
            ftp.login("root", "root");

            //Set File Type "Specially for PDF's"
            ftp.setFileType(FTP.BINARY_FILE_TYPE, FTP.BINARY_FILE_TYPE);
            ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);

            //Change the current Directory to a desired one
            ftp.changeWorkingDirectory("C:\\Users\\abusa\\Desktop\\Intellij\\DealCard\\src\\main\\resources\\templates");

            //get File from the FTP location
            String fileNames[] = ftp.listNames();
            List<String> fTPFileNameList = new ArrayList<String>();

            //Iterate to get File Names
            if (fileNames != null && fileNames.length > 0) {
                for (String fName : fileNames) {
                    fTPFileNameList.add((new File(fName)).getName());
                }
            }

            // Check the file is present on FTP
            if(fileNames != null && fileNames.length > 0 && fTPFileNameList.contains("file.txt")){
                //File is present on FTP
            } else {
                //File is not present on FTP
                String httpURL = "http://localhost";
                InputStream fis = null;
                try{
                    fis = new URL(httpURL).openStream();
                } catch (FileNotFoundException e) {
                    //File is not present on the URL
                }
                ftp.storeFile("file.txt", fis);
                fis.close();
            }
            ftp.logout();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

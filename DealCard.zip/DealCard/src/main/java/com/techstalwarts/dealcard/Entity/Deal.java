package com.techstalwarts.dealcard.Entity;

import lombok.*;

import javax.annotation.Generated;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Setter
@Getter
public class Deal {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer dealId;
    private TypeOfParty accountName;
    private String product;
    private String state;
    private String detailsOfReceivable;
    private Date agreementLetterDate;
    private Date facultyLetterDate;
    private Date sanctionLetterDate;
}

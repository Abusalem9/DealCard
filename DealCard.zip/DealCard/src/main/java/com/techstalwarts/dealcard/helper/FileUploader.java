package com.techstalwarts.dealcard.helper;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileOutputStream;
import java.io.InputStream;
@Service
public class FileUploader {
    public boolean fileDone(MultipartFile file){
        boolean f = false;

        try {
            InputStream s = file.getInputStream();

            byte[] b = new byte[s.available()];

            s.read(b);

            FileOutputStream fs = new FileOutputStream(uploadDirectory+"//"+file.getOriginalFilename());

            fs.write(b);

            fs.flush();
            fs.close();

            f =true;

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return f;
    }
    public final String uploadDirectory = "C:\\Users\\abusa\\Desktop\\Intellij\\DealCard\\src\\main\\resources\\static\\image";
}

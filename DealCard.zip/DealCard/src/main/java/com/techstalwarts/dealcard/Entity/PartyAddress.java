package com.techstalwarts.dealcard.Entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Setter
@Getter
public class PartyAddress {
    @Id
    private Integer id;
    private String city;
    private String state;
    private Integer pinCode;
}

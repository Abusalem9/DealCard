package com.techstalwarts.dealcard.Entity;

public enum PartyConsultantType {
    INDIVIDUAL,COMPANY;
}

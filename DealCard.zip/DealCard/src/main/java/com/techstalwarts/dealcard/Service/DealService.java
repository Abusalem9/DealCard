package com.techstalwarts.dealcard.Service;

import com.techstalwarts.dealcard.Entity.Deal;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DealService {
    Deal createDeal(Deal deal);
    Deal updateDeal(Deal deal);
    String deleteDealByDealId(Integer dealId);

    List<Deal> getAllDeals();

    Deal getDeal(Integer id);
}

async function apiCall(url) {
                let res= await fetch(url);
                return await res.json();
}


function appendArticles(articles, main) {


}

export { apiCall, appendArticles }
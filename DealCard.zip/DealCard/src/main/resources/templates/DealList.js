async function List(url){
    let res= await fetch(url);
    return await res.json();
}

function htmlfile(){
    return " <div id=\"main\">\n" +
        "            <div style=\"background-color: white;\">\n" +
        "                <div style=\"display: flex;gap:10px; justify-content: end;height: 40px\" ><h4 id=\"h2-deal\" class=\"h2-both\">Deal Status</h4> <h4 id=\"h2-status\" class=\"h2-both\">New</h4></div>\n" +
        "            </div>\n" +
        "            <div id=\"deal-details\">\n" +
        "                <div style=\"padding-left: 20px\" >\n" +
        "                    <h4>Upload File</h4>\n" +
        "                    <input type=\"file\" >\n" +
        "                </div>\n" +
        "                <div id=\"main-child\">\n" +
        "                    <h4>Deal ID</h4>\n" +
        "                    <h4 style=\"color: #4a4af8\" id='deal_id'>0</h4>\n" +
        "                </div>\n" +
        "                <div>\n" +
        "                    <div style=\"display: flex;gap: 50px\">\n" +
        "                        <div>\n" +
        "                            <h4>Product</h4>\n" +
        "                            <h4 id='prod_name'>LRD</h4>\n" +
        "                        </div>\n" +
        "                        <div>\n" +
        "                            <h4>Agreement Date</h4>\n" +
        "                            <h4>11-07-2022</h4>\n" +
        "                        </div>\n" +
        "                        <div>\n" +
        "                            <h4>State</h4>\n" +
        "                            <h4>11-07-2022</h4>\n" +
        "                        </div>\n" +
        "                    </div>\n" +
        "                    <div style=\"display: flex;gap: 50px\">\n" +
        "                        <div>\n" +
        "                            <h4>Facility Letter Date</h4>\n" +
        "                            <h4>11-07-2022</h4>\n" +
        "                        </div>\n" +
        "                        <div>\n" +
        "                            <h4>Account Name</h4>\n" +
        "                            <h4>11-07-2022</h4>\n" +
        "                        </div>\n" +
        "                        <div>\n" +
        "                            <h4>Sanction Letter Date</h4>\n" +
        "                            <h4>11-07-2022</h4>\n" +
        "                        </div>\n" +
        "                    </div>\n" +
        "                </div>\n" +
        "                <div>\n" +
        "                    <h4>Details Of Receivable</h4>\n" +
        "                    <h4>Type Of Party</h4>\n" +
        "                </div>\n" +
        "            </div>\n" +
        "        </div>" +
        " <h3>Parties Details</h3>\n" +
        "        <div class=\"party-details\"></div>";
}
export {List,htmlfile};
package com.techstalwarts.dealcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealCardApplicationTests {

	@Test
	void contextLoads() {
	}

}
